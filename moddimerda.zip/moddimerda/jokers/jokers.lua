function shakecard(self) --vibratore di carte
    G.E_MANAGER:add_event(Event({
        func = function()
            self:juice_up(0.5, 0.5)
            return true
        end
    }))
end
--dichiarazione dei joker
SMODS.Atlas({
    key = "amadio_gabriele",
    path = "j_amadio_gabriele.png",
    px = 71,
    py = 95
})


SMODS.Joker{
    key = "amadio_gabriele",                                  --nome del joker
    config = { extra = { Xmult = 2.5, chips = 75   } },    --variabili(chips=chips attuali,chips_mod=aumento di chips)
    pos = { x = 0, y = 0 },                              --sprite
    rarity = 3,                                          --rarita 1=common, 2=uncommen, 3=rare, 4=legendary
    cost = 13,                                            --costo per comprare
    blueprint_compat=true,                               --joker funziona con blueprint?
    eternal_compat=false,                                 --bo
    unlocked = true,                                     --è sbloccato di default
    discovered = true,                                   --è scoperto di default 
    effect=nil,                                          --effetti speciali
    soul_pos=nil,                                        --sprite doppi
    atlas = 'amadio_gabriele',                           --nome nelle dichiarazioni

    calculate = function(self,card,context)              --define calculate functions here
        if context.individual and context.cardarea == G.play then -- if we are in card scoring phase, and we are on individual cards
            if not context.blueprint then -- blueprint/brainstorm don't get to add chips to themselves

            end
        end
        if context.joker_main and context.cardarea == G.jokers then
            if G.GAME.dollars > 24 then -- controlla se hai i soldi
                return {                                     -- risultati
                chips = card.ability.extra.chips, 
                colour = G.C.CHIPS,
                Xmult = card.ability.extra.Xmult,
                colour = G.C.MULT
                }
            end
        end
    end,

}
SMODS.Atlas({
    key = "piergiacomo",
    path = "j_piergiacomo.png",
    px = 71,
    py = 95
})


SMODS.Joker{
    key = "piergiacomo",                                  --nome del joker
    config = { extra = { mult = 7 } },    --variabili(chips=chips attuali,chips_mod=aumento di chips)
    pos = { x = 0, y = 0 },                              --sprite
    rarity = 1,                                          --rarita 1=common, 2=uncommen, 3=rare, 4=legendary
    cost = 6,                                            --costo per comprare
    blueprint_compat=true,                               --joker funziona con blueprint?
    eternal_compat=false,                                 --bo
    unlocked = true,                                     --è sbloccato di default
    discovered = true,                                   --è scoperto di default 
    effect=nil,                                          --effetti speciali
    soul_pos=nil,                                        --sprite doppi
    atlas = 'piergiacomo',                           --nome nelle dichiarazioni

    calculate = function(self,card,context)              --calcoli renali
        if context.individual and context.cardarea == G.play then -- se stiamo a guarda le carte
            if not context.blueprint then -- blueprint/brainstorm non implodono se aggiungi chips a botte

            end
        end
        if context.joker_main and context.cardarea == G.jokers then --turno del joker
            if G.GAME.hands[context.scoring_name].played <= 8 then
                return {                                     -- risultati
                mult = card.ability.extra.mult,
                colour = G.C.MULT
                }
            end
        end
    end,

}
SMODS.Atlas({
    key = "isipisimiaomiao",
    path = "j_isipisimiaomiao.png",
    px = 71,
    py = 95
})


SMODS.Joker{
    key = "isipisimiaomiao",                                  --nome del joker
    config = { extra = { mult = 1 } },    --variabili(chips=chips attuali,chips_mod=aumento di chips)
    pos = { x = 0, y = 0 },                              --sprite
    rarity = 2,                                          --rarita 1=common, 2=uncommen, 3=rare, 4=legendary
    cost = 9,                                            --costo per comprare
    blueprint_compat=true,                               --joker funziona con blueprint?
    eternal_compat=false,                                 --bo
    unlocked = true,                                     --è sbloccato di default
    discovered = true,                                   --è scoperto di default 
    effect=nil,                                          --effetti speciali
    soul_pos=nil,                                        --sprite doppi
    atlas = 'isipisimiaomiao',                           --nome nelle dichiarazioni

    calculate = function(self,card,context)              --calcoli renali
        if context.individual and context.cardarea == G.play then -- se stiamo a guarda le carte
            if not context.blueprint then -- blueprint/brainstorm non implodono se aggiungi chips a botte

            end
        end
        if context.joker_main and context.cardarea == G.jokers then --turno del joker
            if #G.deck.cards > 0 then
                return {                                     -- risultati
                mult = card.ability.extra.mult*#G.deck.cards,
                colour = G.C.MULT
                }
            end
        end
    end,

}
SMODS.Atlas({
    key = "andreacosmico",
    path = "j_andreacosmico.png",
    px = 71,
    py = 95
})
SMODS.Atlas({
    key = "elia_furgone",
    path = "j_elia_furgone.png",
    px = 71,
    py = 95
})

SMODS.Joker{
    key = "andreacosmico",                                  --nome del joker
    config = { extra = { chips = 40 } },    --variabili(chips=chips attuali,chips_mod=aumento di chips)
    pos = { x = 0, y = 0 },                              --sprite
    rarity = 1,                                          --rarita 1=common, 2=uncommen, 3=rare, 4=legendary
    cost = 2,                                            --costo per comprare
    blueprint_compat=true,                               --joker funziona con blueprint?
    eternal_compat=false,                                 --bo
    unlocked = true,                                     --è sbloccato di default
    discovered = true,                                   --è scoperto di default 
    effect=nil,                                          --effetti speciali
    soul_pos=nil,                                        --sprite doppi
    atlas = 'andreacosmico',                           --nome nelle dichiarazioni

       calculate = function(self,card,context)              --define calculate functions here
        if context.individual and context.cardarea == G.play then -- if we are in card scoring phase, and we are on individual cards
            if not context.blueprint then -- blueprint/brainstorm don't get to add chips to themselves

            end
        end
        if context.joker_main and context.cardarea == G.jokers then
                return {                                     -- risultati
                chips = card.ability.extra.chips, 
                colour = G.C.CHIPS,
                }
        end
    end,

}
SMODS.Joker{
    key = "elia_furgone",                                
    config = { extra = { chips = 0, chip_mod = 30 } },  
    pos = { x = 0, y = 0 },                             
    rarity = 2,                                     
    cost = 5,                                            
    blueprint_compat=true,                             
    eternal_compat=true,                             
    unlocked = true,                                   
    discovered = true,                               
    effect=nil,                                         
    soul_pos=nil,                                      
    atlas = 'elia_furgone',                                

    calculate = function(self,card,context)             --letteralmente copie e incolla si sample wee
        if context.individual and context.cardarea == G.play then 
            if not context.blueprint then 
                if context.other_card:get_id() == 14 then 
                    card.ability.extra.chips = card.ability.extra.chips + card.ability.extra.chip_mod 
                    
                    return {                             -- shows a message under the specified card (card) when it triggers, k_upgrade_ex is a key in the localization files of Balatro
                        extra = {focus = card, message = localize('k_upgrade_ex')},
                        card = card,
                        colour = G.C.CHIPS
                    }
                end
            end
        end
        if context.joker_main and context.cardarea == G.jokers then
            return {                                     -- returns total chips from joker to be used in scoring, no need to show message in joker_main phase, game does it for us.
                chips = card.ability.extra.chips, 
                colour = G.C.CHIPS
            }
        end
    end,

    loc_vars = function(self, info_queue, card)          --defines variables to use in the UI. you can use #1# for example to show the chips variable
        return { vars = { card.ability.extra.chips, card.ability.extra.chip_mod }, key = self.key }
    end
}
SMODS.Atlas({
    key = "agnes_tachyon",
    path = "j_agnes.png",
    px = 71,
    py = 95
})
SMODS.Joker{
    key = "agnes_tachyon",                                
    config = { extra = { chips = 0, chip_mod = 50 } },  
    pos = { x = 0, y = 0 },                             
    rarity = 4,                                     
    cost = 16,                                            
    blueprint_compat=true,                             
    eternal_compat=false,                             
    unlocked = true,                                   
    discovered = true,                               
    effect=nil,                                         
    soul_pos=nil,                                      
    atlas = 'agnes_tachyon',                                

    calculate = function(self,card,context)             --letteralmente copie e incolla si sample wee
        if context.individual and context.cardarea == G.play then 
            if not context.blueprint then 
                if context.other_card:get_id() == 10 or context.other_card:get_id() == 9 or context.other_card:get_id() == 8 or context.other_card:get_id() == 7 or context.other_card:get_id() == 6 or context.other_card:get_id() == 5 or context.other_card:get_id() == 4 or context.other_card:get_id() == 3 or context.other_card:get_id() == 2
                 then 
                    card.ability.extra.chips = card.ability.extra.chips + card.ability.extra.chip_mod 
                    
                    return {                             -- shows a message under the specified card (card) when it triggers, k_upgrade_ex is a key in the localization files of Balatro
                        extra = {focus = card, message = localize('k_upgrade_ex')},
                        card = card,
                        colour = G.C.CHIPS
                    }
                end
            end
        end
        if context.joker_main and context.cardarea == G.jokers then
            return {                                     -- returns total chips from joker to be used in scoring, no need to show message in joker_main phase, game does it for us.
                chips = card.ability.extra.chips, 
                colour = G.C.CHIPS
            }
        end
    end,

    loc_vars = function(self, info_queue, card)          --defines variables to use in the UI. you can use #1# for example to show the chips variable
        return { vars = { card.ability.extra.chips, card.ability.extra.chip_mod }, key = self.key }
    end
}
SMODS.Atlas({ --localizzazione
    key = "oksana",
    path = "j_oksana.png",
    px = 71,
    py = 95 --DIOCANE I PIXEL PRECISI SENNO' IMPLODE
})
SMODS.Joker{
    key = "oksana",                                
    config = { extra = { mult = 6 } },  --se ce ne va di più devo cambia la rarita e prezzo
    pos = { x = 0, y = 0 },                             
    rarity = 1,                                     
    cost = 4,                                          
    blueprint_compat=true,       --possibile bug?                      
    eternal_compat=false,   --diocane me devo ricorda de mette false                          
    unlocked = true,                                  
    discovered = true,                               
    effect=nil,     --pk esiste sta funzione                                    
    soul_pos=nil,                                      
    atlas = 'oksana',     --localizzazziozzazzziozazizoaizone                           

    calculate = function(self,card,context)             --calc
        if context.joker_main and context.cardarea == G.jokers then --certo non so come cazzo fa il gioco ad avecce un sistema doppio però vabbè
            return {                                     -- mult
                chips = 6,
                colour = G.C.CHIPS,
                mult = 6,
                colour = G.C.MULT,
            }
        end
    end
}
SMODS.Atlas({
    key = "rea",
    path = "j_rea.png",
    px = 71,
    py = 95
})

SMODS.Joker{
    key = "rea",                                  --nome del joker
    config = { extra = { chips = -2, mult = -1, chips_p = 1000, mult_p = 250 } },    --variabili(chips=chips attuali,chips_mod=aumento di chips)
    pos = { x = 0, y = 0 },                              --sprite
    rarity = 3,                                          --rarita 1=common, 2=uncommen, 3=rare, 4=legendary
    cost = 11,                                            --costo per comprare
    blueprint_compat=false,                               --joker funziona con blueprint?
    eternal_compat=false,                                 --bo
    unlocked = true,                                     --è sbloccato di default
    discovered = true,                                   --è scoperto di default 
    effect=nil,                                          --effetti speciali
    soul_pos=nil,                                        --sprite doppi
    atlas = 'rea',                           --nome nelle dichiarazioni

       calculate = function(self,card,context)              --define calculate functions here
        if context.joker_main and context.cardarea == G.jokers and G.GAME.current_round.hands_left > 1 then
                return {                                     -- risultati
                chips = card.ability.extra.chips, 
                colour = G.C.CHIPS,
                mult = card.ability.extra.mult, 
                colour = G.C.MULT,
                }
            end
                if context.joker_main and context.cardarea == G.jokers and G.GAME.current_round.hands_left <= 1 and G.GAME.dollars > 19 and #G.deck.cards > 24  then
                 return {                                     -- risultati
                chips = card.ability.extra.chips_p, 
                colour = G.C.CHIPS,
                mult = card.ability.extra.mult_p, 
                colour = G.C.MULT,
                }
                end
    end,

}
SMODS.Atlas({
    key = "religious_india",
    path = "j_religious_india.png",
    px = 71,
    py = 95
})

SMODS.Joker{
    key = "religious_india",                                  --nome del joker
    config = { extra = { religiosi = 0, chips_mod = 4, chips1 = 50, mult2 = 3, Xmult6 = 2, chips3 = 200, mult4 = 7, chips5 = 50, mult5 = 10  } },    --variabili(chips=chips attuali,chips_mod=aumento di chips)
    pos = { x = 0, y = 0 },                              --sprite
    rarity = 3,                                          --rarita 1=common, 2=uncommen, 3=rare, 4=legendary
    cost = 7,                                            --costo per comprare
    blueprint_compat=false,                               --joker funziona con blueprint?
    eternal_compat=false,                                 --bo
    unlocked = true,                                     --è sbloccato di default
    discovered = true,                                   --è scoperto di default 
    effect=nil,                                          --effetti speciali
    soul_pos=nil,                                        --sprite doppi
    atlas = 'religious_india',                           --nome nelle dichiarazioni

       calculate = function(self,card,context)              --define calculate functions here
 if context.individual and context.cardarea == G.play then -- if we are in card scoring phase, and we are on individual cards
                if context.other_card:get_id() == 2 or context.other_card:get_id() == 3 or context.other_card:get_id() == 4 or context.other_card:get_id() == 5 or context.other_card:get_id() == 6 or context.other_card:get_id() == 7 or context.other_card:get_id() == 8 or context.other_card:get_id() == 9 or context.other_card:get_id() == 10 or context.other_card:get_id() == 11 or context.other_card:get_id() == 12 or context.other_card:get_id() == 13 or context.other_card:get_id() == 14 then 
                    card.ability.extra.religiosi = card.ability.extra.religiosi + card.ability.extra.chips_mod -- add configurable amount of chips to joker
                    if card.ability.extra.religiosi >= 100 then --tier2
                        card.ability.extra.religiosi = card.ability.extra.religiosi + 3
                        return {                             -- shows a message under the specified card (card) when it triggers, k_upgrade_ex is a key in the localization files of Balatro
                        extra = {focus = card, message = localize('k_upgrade_ex')},
                        card = card,
                        colour = G.C.GREEN
                            }
                        end
                            if card.ability.extra.religiosi >= 350 and card.ability.extra.religiosi < 700 then --tier3
                        card.ability.extra.religiosi = card.ability.extra.religiosi + 10
                        return {                             -- shows a message under the specified card (card) when it triggers, k_upgrade_ex is a key in the localization files of Balatro
                        extra = {focus = card, message = localize('k_upgrade_ex')},
                        card = card,
                        colour = G.C.GREEN
                            }
                        end
                        if card.ability.extra.religiosi >= 700 and card.ability.extra.religiosi < 1800 then --tier4
                        card.ability.extra.religiosi = card.ability.extra.religiosi + 26
                        return {                             -- shows a message under the specified card (card) when it triggers, k_upgrade_ex is a key in the localization files of Balatro
                        extra = {focus = card, message = localize('k_upgrade_ex')},
                        card = card,
                        colour = G.C.GREEN
                            }
                        end
                        if card.ability.extra.religiosi >= 1800 and card.ability.extra.religiosi < 7500 then --tier5
                        card.ability.extra.religiosi = card.ability.extra.religiosi + 246
                        return {                             -- shows a message under the specified card (card) when it triggers, k_upgrade_ex is a key in the localization files of Balatro
                        extra = {focus = card, message = localize('k_upgrade_ex')},
                        card = card,
                        colour = G.C.GREEN
                            }
                        end
                        if card.ability.extra.religiosi >= 7500 and card.ability.extra.religiosi < 45000 then --tier6
                        card.ability.extra.religiosi = card.ability.extra.religiosi + 996
                        return {                             -- shows a message under the specified card (card) when it triggers, k_upgrade_ex is a key in the localization files of Balatro
                        extra = {focus = card, message = localize('k_upgrade_ex')},
                        card = card,
                        colour = G.C.GREEN
                            }
                        end
                        if card.ability.extra.religiosi >= 45000 then --tier6
                        card.ability.extra.religiosi = card.ability.extra.religiosi + 996
                        return {                             -- shows a message under the specified card (card) when it triggers, k_upgrade_ex is a key in the localization files of Balatro
                        extra = {focus = card, message = localize('k_upgrade_ex')},
                        card = card,
                        colour = G.C.GREEN
                            }
                        end
                        
                    return {                             -- shows a message under the specified card (card) when it triggers, k_upgrade_ex is a key in the localization files of Balatro
                        extra = {focus = card, message = localize('k_upgrade_ex')},
                        card = card,
                        colour = G.C.GREEN
                    }
                end
        end
            if context.joker_main and context.cardarea == G.jokers and  card.ability.extra.religiosi >= 100 and card.ability.extra.religiosi < 350 then --certo non so come cazzo fa il gioco ad avecce un sistema doppio però vabbè
            return {                                     -- mult
                chips = card.ability.extra.chips1,
                colour = G.C.CHIPS,
            }
            end
            if context.joker_main and context.cardarea == G.jokers and  card.ability.extra.religiosi >= 350 and card.ability.extra.religiosi < 700 then --certo non so come cazzo fa il gioco ad avecce un sistema doppio però vabbè
            return {                                     -- mult
                chips = card.ability.extra.chips1,
                colour = G.C.CHIPS,
                mult = card.ability.extra.mult2,
                colour = G.C.MULT,
            }
            end
            if context.joker_main and context.cardarea == G.jokers and  card.ability.extra.religiosi >= 700 and card.ability.extra.religiosi < 1800 then --certo non so come cazzo fa il gioco ad avecce un sistema doppio però vabbè
            return {                                     -- mult
                chips = card.ability.extra.chips1,
                colour = G.C.CHIPS,
                mult = card.ability.extra.mult2,
                colour = G.C.MULT,
                chips = card.ability.extra.chips3,
                colour = G.C.CHIPS,
            }
            end
            if context.joker_main and context.cardarea == G.jokers and  card.ability.extra.religiosi >= 1800 and card.ability.extra.religiosi < 7500 then --certo non so come cazzo fa il gioco ad avecce un sistema doppio però vabbè
            return {                                     -- mult
                chips = card.ability.extra.chips1,
                colour = G.C.CHIPS,
                mult = card.ability.extra.mult2,
                colour = G.C.MULT,
                chips = card.ability.extra.chips3,
                colour = G.C.CHIPS,
                mult = card.ability.extra.mult4,
                colour = G.C.MULT,
            }
            end
            if context.joker_main and context.cardarea == G.jokers and  card.ability.extra.religiosi >= 7500 and card.ability.extra.religiosi < 45000 then --certo non so come cazzo fa il gioco ad avecce un sistema doppio però vabbè
            return {                                     -- mult
                chips = card.ability.extra.chips1,
                colour = G.C.CHIPS,
                mult = card.ability.extra.mult2,
                colour = G.C.MULT,
                chips = card.ability.extra.chips3,
                colour = G.C.CHIPS,
                mult = card.ability.extra.mult4,
                colour = G.C.MULT,
                chips = card.ability.extra.chips5,
                colour = G.C.CHIPS,
                mult = card.ability.extra.mult5,
                colour = G.C.MULT,
            }
            end
            if context.joker_main and context.cardarea == G.jokers and  card.ability.extra.religiosi >= 45000 then --certo non so come cazzo fa il gioco ad avecce un sistema doppio però vabbè
            return {                                     -- mult
                chips = card.ability.extra.chips1,
                colour = G.C.CHIPS,
                mult = card.ability.extra.mult2,
                colour = G.C.MULT,
                chips = card.ability.extra.chips3,
                colour = G.C.CHIPS,
                mult = card.ability.extra.mult4,
                colour = G.C.MULT,
                chips = card.ability.extra.chips5,
                colour = G.C.CHIPS,
                mult = card.ability.extra.mult5,
                colour = G.C.MULT,
                Xmult = card.ability.extra.Xmult6,
                colour = G.C.MULT,
            }
            end
    end,

    loc_vars = function(self, info_queue, card)          --defines variables to use in the UI. you can use #1# for example to show the chips variable
        return { vars = { card.ability.extra.religiosi, card.ability.extra.chips_mod }, key = self.key }
    end

}

------------------------------------------------------------------------------------
--TEAMKILL DI SBONDI
--SBONDI
--ELIA
--WT
--DARK
--ZUCCHINA
--FILIBERTO
--TOSTI
--ERWIN
--GOLDSHIP
--RICE SHOWER
--HARU URARA
--MIHON BOURBON
--TELONE TRANSPORT
--MINOS
--PAVIMENTO DI SBONDI
--GOLDSHIP(rl)
--shuffle dance
--teio(immagine dove ti spia)
--WOT
--oarai team
