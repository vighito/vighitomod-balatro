return {
    descriptions = {
        Joker = {
            j_sj_amadio_gabriele = {
                name = "Amadio Gabriele",
                text = {
                    {
                    "{C:chips}+75{} Chips",
                    "{X:mult,C:white} X2.5{} Mult",
                    "When you have more than {C:money}25${}",
                    }
                },
            },
                j_sj_piergiacomo = {
                name = "Piergiacomo",
                text = {
                    {
                    "{C:mult} +7{} Mult",
                    "When Current played hand is played less or equal to {C:attention}8{} times",
                    }
                },
            },
                j_sj_isipisimiaomiao = {
                name = "isi pisi miao miao",
                text = {
                    {
                    "{C:mult} +1{} Mult for each remaining card in {C:attention}deck{}",
                    }
                },
            },     
                j_sj_andreacosmico = {
                name = "Andrea Cosmico",
                text = {
                    {
                    "{C:chips}+40{} Chips",
                    }
                },
            },
            j_sj_elia_furgone = {
                name = "Elia furgone",
                text = {
                    {
                    "This Joker gains",
                    "{C:chips}+#2#{} Chips when each",
                    "played {C:attention}Ace{} is scored",
                    "{C:inactive}(Currently {C:chips}+#1#{C:inactive} Chips)",
                    }
                },
            },   
            j_sj_agnes_tachyon = {
                name = "Agnes Tachyon",
                text = {
                    {
                    "This Joker gains",
                    "{C:chips}+#2#{} Chips when each",
                    "{C:attention}Number{} card is scored",
                    "{C:inactive}(Currently {C:chips}+#1#{C:inactive} Chips)",
                    }
                },
            },    
         j_sj_oksana = {
                name = "oksana",
                text = {
                    {
                   "{C:chips}6{}{C:mult}6{}",
                    }
                },
            },    
            j_sj_rea = {
                name = "rea",
                text = {
                    {
                   "{C:attention}Kill yourself{}",
                    }
                },
            },  
            j_sj_religious_india = {
                name = "religious india",
                text = {
                    "gains {C:green}believers{} when each card is scored",
                    "{C:inactive}(Currently {C:green}#1#{}{C:inactive} believers){}",
                    "the {C:attention}more{} you have, the {C:attention}better{} it gets",
                    "{C:attention}the {}{C:green}believers{}{C:attention} gained will be higher the more it has them{}",
                },
            }, 
            --tut
            j_sj_sample_wee = {
                name = "Sample Wee",
                text = {
                    "This Joker gains",
                    "{C:chips}+#2#{} Chips when each",
                    "played {C:attention}2{} is scored",
                    "{C:inactive}(Currently {C:chips}+#1#{C:inactive} Chips)",
                },
            },
            j_sj_sample_obelisk = {
                name = "Sample Obelisk",
                text = {
                    {
                        "This Joker gives {X:mult,C:white} X#1# {} Mult",
                        "for each time you've played this {C:attention}hand",
                    }
                },
            },
            j_sj_sample_specifichand = {
                name = "Sample Specific Hand",
                text = {
                    {
                        "If the hand played is #1#,",
                        "Gives {X:mult,C:white} X#2# {} Mult"
                    }
                },
            },
            j_sj_sample_money = {
                name = "Sample Money",
                text = {
                    {
                        "Earn (Ante x 2) {C:money}${} at",
                        "end of round, also here's some text effects:",
                        "{C:money} money{}, {C:chips} chips{}, {C:mult} mult{}, {C:red} red{}, {C:blue} blue{}, {C:green} green{}",
                        "{C:attention} attention{}, {C:purple} purple{}, {C:inactive} inactive{}",
                        "{C:spades} spades{}, {C:hearts} hearts{}, {C:clubs} clubs{}, {C:diamonds} diamonds{}",
                        "{C:tarot} tarot{}, {C:planet} planet{}, {C:spectral} spectral{}",
                        "{C:edition} edition{}, {C:dark_edition} dark edition{}, {C:legendary} legendary{}, {C:enhanced} enhanced{}",
                    }
                },
            },
            j_sj_sample_roomba = {
                name = "Sample Roomba",
                text = {
                    {
                        "Attempts to remove edition",
                        "from another Joker",
                        "at the end of each round",
                        "{C:inactive}(Foil, Holo, Polychrome)"
                    }
                },
            },
            j_sj_sample_drunk_juggler = {
                name = "Sample Drunk Juggler",
                text = {
                    {
                        "{C:red}+#1#{} discard,",
                        "also here's some {X:legendary,C:white}text effects{}:",
                        "{s:0.5} scaled down by 0.5",
                        "{C:attention,T:tag_double}#2#",
                    }
                },
            },
            j_sj_sample_hackerman = {
                name = "Sample Hackerman",
                text = {
                    {
                        "Retrigger",
                        "each played",
                        "{C:attention}6{}, {C:attention}7{}, {C:attention}8{}, or {C:attention}9{}",
                    }
                },
            },
            j_sj_sample_baroness = {
                name = "Sample Baroness",
                text = {
                    {
                        "Each {C:attention}Queen{}",
                        "held in hand",
                        "gives {X:mult,C:white} X#1# {} Mult",
                    }
                },
            },
            j_sj_sample_rarebaseballcard = {
                name = "Sample Rare Baseball Card",
                text = {
                    {
                        "{X:mult,C:white}Rare{} Jokers",
                        "each give {X:mult,C:white} X#1# {} Mult",
                    }
                },
            },
            j_sj_sample_multieffect = {
                name = "Sample Multi-Effect",
                text = {
                    {
                        "Each played {C:attention}10{}",
                        "gives {C:chips}+#1#{} Chips and",
                        "{C:mult}+#2#{} Mult when scored",
                    }
                },
            }
        }
    },
    misc = {

            -- do note that when using messages such as: 
            -- message = localize{type='variable',key='a_xmult',vars={current_xmult}},
            -- that the key 'a_xmult' will use provided values from vars={} in that order to replace #1#, #2# etc... in the localization file.


        dictionary = {
            a_chips="+#1#",
            a_chips_minus="-#1#",
            a_hands="+#1# Hands",
            a_handsize="+#1# Hand Size",
            a_handsize_minus="-#1# Hand Size",
            a_mult="+#1# Mult",
            a_mult_minus="-#1# Mult",
            a_remaining="#1# Remaining",
            a_sold_tally="#1#/#2# Sold",
            a_xmult="X#1# Mult",
            a_xmult_minus="-X#1# Mult",
        }
    }
}